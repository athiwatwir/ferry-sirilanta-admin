<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['text' => 'Create New','href'=>'javascript:void(0);']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['text' => 'Create New','href'=>'javascript:void(0);']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="dt-buttons btn-group flex-wrap mb-2" bis_skin_checked="1">
    <a href="<?php echo e($href); ?>" class="btn btn-lg btn-primary btn-hover" tabindex="0" aria-controls="DataTables_Table_0" type="button">
        <span><i class="icon-base  ti tabler-plus icon-16px me-md-2"></i>
            <span class="d-md-inline-block d-none"><?php echo e($text); ?>

            </span>
        </span>
    </a>
</div>
<?php /**PATH D:\projects\Git\ferry-sirilanta-admin\resources\views/components/button/new.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'action'=>'',
'method'=>'POST',
'id'=>'frm',
'type'=>'',
'backUrl'=>url()->previous(),
'isshow_button'=>true
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'action'=>'',
'method'=>'POST',
'id'=>'frm',
'type'=>'',
'backUrl'=>url()->previous(),
'isshow_button'=>true
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<form id="<?php echo e($id); ?>" class="mb-3 browser-default-validatio p-3" id="<?php echo e($id); ?>" action="<?php echo e($action); ?>" method="<?php echo e($method); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo e($slot); ?>


    <?php if($isshow_button): ?>
    <hr>
    <div class="row">
        <div class="col text-center">
            <div class="">
                <?php if($type=='modal'): ?>
                <button type="button" class="btn btn-label-secondary waves-effect me-2 btn-hover" data-bs-dismiss="modal">Close</button>
                <?php else: ?>
                <a href="<?php echo e($backUrl); ?>" class="btn btn-label-secondary waves-effect me-2 btn-hover">Discard</a>
                <?php endif; ?>

                <button type="submit" class="btn btn-success waves-effect btn-hover"><i class="icon-base ti tabler-device-floppy"></i> Save</button>
            </div>
        </div>
    </div>
    <?php endif; ?>

</form>
<?php /**PATH D:\projects\Git\ferry-sirilanta-admin\resources\views/components/form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="row">
        <div class="col-12 col-lg-4">
            <?php if (isset($component)) { $__componentOriginalddcc4b02e76cebdff4539e576a9da27b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalddcc4b02e76cebdff4539e576a9da27b = $attributes; } ?>
<?php $component = App\View\Components\Station\DepartSelection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('station.depart-selection'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Station\DepartSelection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'From Station','isrequire' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalddcc4b02e76cebdff4539e576a9da27b)): ?>
<?php $attributes = $__attributesOriginalddcc4b02e76cebdff4539e576a9da27b; ?>
<?php unset($__attributesOriginalddcc4b02e76cebdff4539e576a9da27b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalddcc4b02e76cebdff4539e576a9da27b)): ?>
<?php $component = $__componentOriginalddcc4b02e76cebdff4539e576a9da27b; ?>
<?php unset($__componentOriginalddcc4b02e76cebdff4539e576a9da27b); ?>
<?php endif; ?>
        </div>
        <div class="col-12 col-lg-4">
            <?php if (isset($component)) { $__componentOriginalddcc4b02e76cebdff4539e576a9da27b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalddcc4b02e76cebdff4539e576a9da27b = $attributes; } ?>
<?php $component = App\View\Components\Station\DepartSelection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('station.depart-selection'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Station\DepartSelection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'To Station','isrequire' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalddcc4b02e76cebdff4539e576a9da27b)): ?>
<?php $attributes = $__attributesOriginalddcc4b02e76cebdff4539e576a9da27b; ?>
<?php unset($__attributesOriginalddcc4b02e76cebdff4539e576a9da27b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalddcc4b02e76cebdff4539e576a9da27b)): ?>
<?php $component = $__componentOriginalddcc4b02e76cebdff4539e576a9da27b; ?>
<?php unset($__componentOriginalddcc4b02e76cebdff4539e576a9da27b); ?>
<?php endif; ?>
        </div>

    </div>
    <?php if (isset($component)) { $__componentOriginalf9a5f060e1fbbcbc7beb643b113b10ab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9a5f060e1fbbcbc7beb643b113b10ab = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form','data' => ['action' => route('route.store')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('route.store'))]); ?>
        <div class="row">

            <div class="col-12">
                <table class="table table-sm table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Depart Time</th>
                            <th>Arrive Time</th>
                            <th>Type</th>
                            <th>Seat</th>
                            <th>Regular Price</th>

                            <th>Child Price</th>
                            <th>Infant Price</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr class="">
                            <td colspan="9">
                                <?php if (isset($component)) { $__componentOriginal4d13db363050fc0eb817f9db0ddf4b57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d13db363050fc0eb817f9db0ddf4b57 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.route.route-title-row','data' => ['departStation' => $route['departure_station'],'destStation' => $route['destination_station']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('route.route-title-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['departStation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($route['departure_station']),'destStation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($route['destination_station'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d13db363050fc0eb817f9db0ddf4b57)): ?>
<?php $attributes = $__attributesOriginal4d13db363050fc0eb817f9db0ddf4b57; ?>
<?php unset($__attributesOriginal4d13db363050fc0eb817f9db0ddf4b57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d13db363050fc0eb817f9db0ddf4b57)): ?>
<?php $component = $__componentOriginal4d13db363050fc0eb817f9db0ddf4b57; ?>
<?php unset($__componentOriginal4d13db363050fc0eb817f9db0ddf4b57); ?>
<?php endif; ?>
                            </td>


                        </tr>

                        <?php $__currentLoopData = $route['sub_routes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subRoute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php if($subRoute['type']=='activity' ): ?> table-active <?php endif; ?> pointer" data-id="<?php echo e($subRoute['agent_sub_route_id']); ?>" data-action="selected">
                            <td>
                                <div class="form-check form-check-success">
                                    <input class="form-check-input" type="checkbox" name="agent_sub_route_ids[]" value="<?php echo e($subRoute['agent_sub_route_id']); ?>" id="chk_<?php echo e($subRoute['agent_sub_route_id']); ?>" />

                                </div>
                            </td>
                            <td>
                                <strong>
                                    <?php if (isset($component)) { $__componentOriginald49e61fa434bee7de04555c8528c400a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald49e61fa434bee7de04555c8528c400a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-time','data' => ['time' => $subRoute['depart_time']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-time'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['time' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['depart_time'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald49e61fa434bee7de04555c8528c400a)): ?>
<?php $attributes = $__attributesOriginald49e61fa434bee7de04555c8528c400a; ?>
<?php unset($__attributesOriginald49e61fa434bee7de04555c8528c400a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald49e61fa434bee7de04555c8528c400a)): ?>
<?php $component = $__componentOriginald49e61fa434bee7de04555c8528c400a; ?>
<?php unset($__componentOriginald49e61fa434bee7de04555c8528c400a); ?>
<?php endif; ?></strong>
                                <br><small><?php echo e($subRoute['origin_timezone']); ?></small>
                            </td>
                            <td>
                                <?php if (isset($component)) { $__componentOriginald49e61fa434bee7de04555c8528c400a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald49e61fa434bee7de04555c8528c400a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-time','data' => ['time' => $subRoute['arrival_time']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-time'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['time' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['arrival_time'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald49e61fa434bee7de04555c8528c400a)): ?>
<?php $attributes = $__attributesOriginald49e61fa434bee7de04555c8528c400a; ?>
<?php unset($__attributesOriginald49e61fa434bee7de04555c8528c400a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald49e61fa434bee7de04555c8528c400a)): ?>
<?php $component = $__componentOriginald49e61fa434bee7de04555c8528c400a; ?>
<?php unset($__componentOriginald49e61fa434bee7de04555c8528c400a); ?>
<?php endif; ?>
                                <br><small><?php echo e($subRoute['destination_timezone']); ?></small>
                            </td>
                            <td class="">
                                <?php if($subRoute['type']=='activity'): ?>
                                <span class="badge bg-label-info">Activity route</span><br>
                                <?php endif; ?>
                                <?php echo e($subRoute['boat_type']); ?> <br />

                                <div class="col-12 d-flex align-items-center flex-wrap">

                                    <?php if(!empty($subRoute['icons'])): ?>
                                    <?php $__currentLoopData = $subRoute['icons']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="avatar avatar-sm me-4 position-relative">
                                        <img src="<?php echo e($icon); ?>" alt="Avatar">
                                        <small></small>

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <?php if (isset($component)) { $__componentOriginaldb12de5da9d1678ccad864eb19c0c030 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb12de5da9d1678ccad864eb19c0c030 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-number','data' => ['number' => $subRoute['seatamt']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['seatamt'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb12de5da9d1678ccad864eb19c0c030)): ?>
<?php $attributes = $__attributesOriginaldb12de5da9d1678ccad864eb19c0c030; ?>
<?php unset($__attributesOriginaldb12de5da9d1678ccad864eb19c0c030); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb12de5da9d1678ccad864eb19c0c030)): ?>
<?php $component = $__componentOriginaldb12de5da9d1678ccad864eb19c0c030; ?>
<?php unset($__componentOriginaldb12de5da9d1678ccad864eb19c0c030); ?>
<?php endif; ?>
                            </td>
                            <td class="">
                                <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['price' => $subRoute['cost_price']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['price' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['cost_price'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
                            </td>

                            <td class="">
                                <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['price' => $subRoute['cost_child_price']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['price' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['cost_child_price'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
                            </td>

                            <td class="">
                                <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['price' => $subRoute['cost_infant_price']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['price' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['cost_infant_price'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9a5f060e1fbbcbc7beb643b113b10ab)): ?>
<?php $attributes = $__attributesOriginalf9a5f060e1fbbcbc7beb643b113b10ab; ?>
<?php unset($__attributesOriginalf9a5f060e1fbbcbc7beb643b113b10ab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9a5f060e1fbbcbc7beb643b113b10ab)): ?>
<?php $component = $__componentOriginalf9a5f060e1fbbcbc7beb643b113b10ab; ?>
<?php unset($__componentOriginalf9a5f060e1fbbcbc7beb643b113b10ab); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script>
    $(document).ready(function() {

        // ถ้ามีการสร้างแถวแบบไดนามิก ให้ใช้ delegated event แบบนี้
        $(document).on('click', 'tr[data-action="selected"]', function(e) {
            // ถ้าคลิกที่ checkbox เอง ไม่ต้อง toggle ซ้ำ
            if ($(e.target).is('input[type="checkbox"], label, a, button')) return;

            const $chk = $(this).find('input[type="checkbox"]');
            const checked = !$chk.prop('checked');

            $chk.prop('checked', checked).trigger('change'); // เผื่อมี handler อื่นฟังอยู่
            $(this).toggleClass('table-active', checked); // ใส่/เอา class ไฮไลท์ตามต้องการ
        });

        // กัน event เด้งขึ้นไปถึง tr เวลาคลิก checkbox โดยตรง (ทางเลือก)
        $(document).on('click', 'tr[data-action="selected"] input[type="checkbox"]', function(e) {
            e.stopPropagation();
        });



    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\Git\ferry-sirilanta-admin\resources\views/pages/route/create.blade.php ENDPATH**/ ?>
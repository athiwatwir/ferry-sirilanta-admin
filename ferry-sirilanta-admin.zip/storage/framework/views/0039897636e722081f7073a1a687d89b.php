<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'name'=>'isactive',
'label'=>'On',
'value'=>'N'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'name'=>'isactive',
'label'=>'On',
'value'=>'N'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<label class="switch switch-lg switch-success">
    <input type="checkbox" class="switch-input" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" value="<?php echo e($value); ?>" <?php if($value=='Y' ): echo 'checked'; endif; ?> />
    <span class="switch-toggle-slider">
        <span class="switch-on">
            <i class="icon-base ti tabler-check"></i>
        </span>
        <span class="switch-off">
            <i class="icon-base ti tabler-x"></i>
        </span>
    </span>
    <span class="switch-label"><?php echo e($label); ?></span>
</label>
<?php /**PATH D:\projects\Git\ferry-sirilanta-admin\resources\views/components/form/switch.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label' => 'Station', 'name' => '','selected'=>'','isrequire'=>true,'empty'=>'- ALL -' ]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label' => 'Station', 'name' => '','selected'=>'','isrequire'=>true,'empty'=>'- ALL -' ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>


<div class="form-floating mb-2">
    <select class="form-select" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" <?php if($isrequire): echo 'required'; endif; ?>>
        <option value="" selected><?php echo e($empty); ?></option>
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $stations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <optgroup label="<?php echo e($index); ?>">
            <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($station['id']); ?>" <?php if($selected==$station['id']): echo 'selected'; endif; ?>>
                <?php echo e(sprintf('[%s] %s', $station['nickname'], $station['name'])); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </optgroup>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="<?php echo e($name); ?>"><?php echo e($label); ?> <?php if($isrequire): ?>
        <strong class="text-danger">*</strong>
        <?php endif; ?></label>
</div>
<?php /**PATH D:\projects\Git\ferry-sirilanta-admin\resources\views/components/station/depart-selection.blade.php ENDPATH**/ ?>
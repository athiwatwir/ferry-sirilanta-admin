<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="row">
        <div class="col-12 col-lg-10">
            <?php if (isset($component)) { $__componentOriginal9e59b8f8d91efe5f9fd474a2a8c1b428 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e59b8f8d91efe5f9fd474a2a8c1b428 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.station.route-title','data' => ['departStation' => $route['departure_station'],'destStation' => $route['destination_station']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('station.route-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['departStation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($route['departure_station']),'destStation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($route['destination_station'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e59b8f8d91efe5f9fd474a2a8c1b428)): ?>
<?php $attributes = $__attributesOriginal9e59b8f8d91efe5f9fd474a2a8c1b428; ?>
<?php unset($__attributesOriginal9e59b8f8d91efe5f9fd474a2a8c1b428); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e59b8f8d91efe5f9fd474a2a8c1b428)): ?>
<?php $component = $__componentOriginal9e59b8f8d91efe5f9fd474a2a8c1b428; ?>
<?php unset($__componentOriginal9e59b8f8d91efe5f9fd474a2a8c1b428); ?>
<?php endif; ?>

        </div>


    </div>
    <hr>

    <div class="row">
        <div class="col-12">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Depart Time</th>
                        <th>Arrive Time</th>
                        <th>Type</th>
                        <th>Seat</th>
                        <th>Price</th>

                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $route['sub_routes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subRoute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr <?php if($subRoute['type']=='activity' ): ?> class="table-active" <?php endif; ?>>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <strong>
                                <?php if (isset($component)) { $__componentOriginald49e61fa434bee7de04555c8528c400a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald49e61fa434bee7de04555c8528c400a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-time','data' => ['time' => $subRoute['depart_time']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-time'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['time' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['depart_time'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald49e61fa434bee7de04555c8528c400a)): ?>
<?php $attributes = $__attributesOriginald49e61fa434bee7de04555c8528c400a; ?>
<?php unset($__attributesOriginald49e61fa434bee7de04555c8528c400a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald49e61fa434bee7de04555c8528c400a)): ?>
<?php $component = $__componentOriginald49e61fa434bee7de04555c8528c400a; ?>
<?php unset($__componentOriginald49e61fa434bee7de04555c8528c400a); ?>
<?php endif; ?></strong>
                            <br><small><?php echo e($subRoute['origin_timezone']); ?></small>
                        </td>
                        <td>
                            <?php if (isset($component)) { $__componentOriginald49e61fa434bee7de04555c8528c400a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald49e61fa434bee7de04555c8528c400a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-time','data' => ['time' => $subRoute['arrival_time']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-time'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['time' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['arrival_time'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald49e61fa434bee7de04555c8528c400a)): ?>
<?php $attributes = $__attributesOriginald49e61fa434bee7de04555c8528c400a; ?>
<?php unset($__attributesOriginald49e61fa434bee7de04555c8528c400a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald49e61fa434bee7de04555c8528c400a)): ?>
<?php $component = $__componentOriginald49e61fa434bee7de04555c8528c400a; ?>
<?php unset($__componentOriginald49e61fa434bee7de04555c8528c400a); ?>
<?php endif; ?>
                            <br><small><?php echo e($subRoute['destination_timezone']); ?></small>
                        </td>
                        <td class="">
                            <?php if($subRoute['type']=='activity'): ?>
                            <span class="badge bg-label-info">Activity route</span><br>
                            <?php endif; ?>
                            <?php echo e($subRoute['boat_type']); ?> <br />

                            <div class="col-12 d-flex align-items-center flex-wrap">

                                <?php if(!empty($subRoute['icons'])): ?>
                                <?php $__currentLoopData = $subRoute['icons']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="avatar avatar-sm me-4 position-relative">
                                    <img src="<?php echo e($icon); ?>" alt="Avatar">
                                    <small></small>

                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <?php if (isset($component)) { $__componentOriginaldb12de5da9d1678ccad864eb19c0c030 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb12de5da9d1678ccad864eb19c0c030 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-number','data' => ['number' => $subRoute['seatamt']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['seatamt'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb12de5da9d1678ccad864eb19c0c030)): ?>
<?php $attributes = $__attributesOriginaldb12de5da9d1678ccad864eb19c0c030; ?>
<?php unset($__attributesOriginaldb12de5da9d1678ccad864eb19c0c030); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb12de5da9d1678ccad864eb19c0c030)): ?>
<?php $component = $__componentOriginaldb12de5da9d1678ccad864eb19c0c030; ?>
<?php unset($__componentOriginaldb12de5da9d1678ccad864eb19c0c030); ?>
<?php endif; ?>
                        </td>
                        <td>


                        </td>

                        <td class="text-center">



                        </td>

                        <td class="text-end">


                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('assets/vendor/libs/cleave-zen/cleave-zen.js')); ?>"></script>
<script src="<?php echo e(asset('js/sub-route/time-calculate.js')); ?>"></script>

<script>
    $(document).ready(function() {
        $('#bt-create').on('click', function() {
            $('#box-create').show();
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\Git\ferry-sirilanta-admin\resources\views/pages/route/show.blade.php ENDPATH**/ ?>
<?php if(Session::has('success')): ?>
<script>
    window.addEventListener('DOMContentLoaded', function() {
        Swal.fire({
            title: 'Success!'
            , text: <?php echo json_encode(Session::get('success'), 15, 512) ?>
            , icon: 'success'
            , confirmButtonText: 'OK'
            , customClass: {
                confirmButton: 'btn btn-primary'
            }
            , buttonsStyling: false
            , timer: 2000
            , showConfirmButton: false
        , });
    });

</script>
<?php endif; ?>


<?php if(Session::has('error')): ?>
<script>
    Swal.fire({
        icon: "error"
        , title: 'Error!'
        , text: <?php echo json_encode(Session::get('error'), 15, 512) ?>
        , type: 'error'
        , customClass: {
            confirmButton: 'btn btn-primary'
        }
        , buttonsStyling: false
    })

</script>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
<div class="hide toast-on-load" data-toast-type="warning" data-toast-title="" data-toast-body="<?php echo e(Session::get('warning')); ?>" data-toast-pos="top-end" data-toast-delay="4000" data-toast-fill="true">
</div>
<?php endif; ?>
<?php /**PATH D:\projects\Git\ferry-sirilanta-admin\resources\views/layouts/section/flashmessage.blade.php ENDPATH**/ ?>
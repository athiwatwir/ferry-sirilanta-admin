<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="row">
        <div class="col-12 col-lg-4">
            <?php if (isset($component)) { $__componentOriginalddcc4b02e76cebdff4539e576a9da27b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalddcc4b02e76cebdff4539e576a9da27b = $attributes; } ?>
<?php $component = App\View\Components\Station\DepartSelection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('station.depart-selection'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Station\DepartSelection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'From Station','isrequire' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalddcc4b02e76cebdff4539e576a9da27b)): ?>
<?php $attributes = $__attributesOriginalddcc4b02e76cebdff4539e576a9da27b; ?>
<?php unset($__attributesOriginalddcc4b02e76cebdff4539e576a9da27b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalddcc4b02e76cebdff4539e576a9da27b)): ?>
<?php $component = $__componentOriginalddcc4b02e76cebdff4539e576a9da27b; ?>
<?php unset($__componentOriginalddcc4b02e76cebdff4539e576a9da27b); ?>
<?php endif; ?>
        </div>
        <div class="col-12 col-lg-4">
            <?php if (isset($component)) { $__componentOriginalddcc4b02e76cebdff4539e576a9da27b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalddcc4b02e76cebdff4539e576a9da27b = $attributes; } ?>
<?php $component = App\View\Components\Station\DepartSelection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('station.depart-selection'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Station\DepartSelection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'To Station','isrequire' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalddcc4b02e76cebdff4539e576a9da27b)): ?>
<?php $attributes = $__attributesOriginalddcc4b02e76cebdff4539e576a9da27b; ?>
<?php unset($__attributesOriginalddcc4b02e76cebdff4539e576a9da27b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalddcc4b02e76cebdff4539e576a9da27b)): ?>
<?php $component = $__componentOriginalddcc4b02e76cebdff4539e576a9da27b; ?>
<?php unset($__componentOriginalddcc4b02e76cebdff4539e576a9da27b); ?>
<?php endif; ?>
        </div>
        <div class="col-12 col-lg-4 text-end">
            <?php if (isset($component)) { $__componentOriginal2ddbcc2abbd70977e6b075de7cbd13eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbcc2abbd70977e6b075de7cbd13eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button.new','data' => ['text' => 'Add Route','href' => route('route.create')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button.new'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => 'Add Route','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('route.create'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbcc2abbd70977e6b075de7cbd13eb)): ?>
<?php $attributes = $__attributesOriginal2ddbcc2abbd70977e6b075de7cbd13eb; ?>
<?php unset($__attributesOriginal2ddbcc2abbd70977e6b075de7cbd13eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbcc2abbd70977e6b075de7cbd13eb)): ?>
<?php $component = $__componentOriginal2ddbcc2abbd70977e6b075de7cbd13eb; ?>
<?php unset($__componentOriginal2ddbcc2abbd70977e6b075de7cbd13eb); ?>
<?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <table class="table table-sm table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Depart Time</th>
                        <th>Arrive Time</th>
                        <th>Type</th>
                        <th>Seat</th>
                        <th>Regular Price</th>

                        <th>Child Price</th>
                        <th>Infant Price</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="">
                        <td colspan="9">
                            <?php if (isset($component)) { $__componentOriginal4d13db363050fc0eb817f9db0ddf4b57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d13db363050fc0eb817f9db0ddf4b57 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.route.route-title-row','data' => ['departStation' => $route['departure_station'],'destStation' => $route['destination_station']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('route.route-title-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['departStation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($route['departure_station']),'destStation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($route['destination_station'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d13db363050fc0eb817f9db0ddf4b57)): ?>
<?php $attributes = $__attributesOriginal4d13db363050fc0eb817f9db0ddf4b57; ?>
<?php unset($__attributesOriginal4d13db363050fc0eb817f9db0ddf4b57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d13db363050fc0eb817f9db0ddf4b57)): ?>
<?php $component = $__componentOriginal4d13db363050fc0eb817f9db0ddf4b57; ?>
<?php unset($__componentOriginal4d13db363050fc0eb817f9db0ddf4b57); ?>
<?php endif; ?>
                        </td>


                    </tr>

                    <?php $__currentLoopData = $route['sub_routes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subRoute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr <?php if($subRoute['type']=='activity' ): ?> class="table-active" <?php endif; ?>>
                        <td>
                            <?php if (isset($component)) { $__componentOriginal3393560a65f36031a8fc2de39b5ab719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3393560a65f36031a8fc2de39b5ab719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.switch','data' => ['label' => '','value' => $subRoute['isactive']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => '','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['isactive'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3393560a65f36031a8fc2de39b5ab719)): ?>
<?php $attributes = $__attributesOriginal3393560a65f36031a8fc2de39b5ab719; ?>
<?php unset($__attributesOriginal3393560a65f36031a8fc2de39b5ab719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3393560a65f36031a8fc2de39b5ab719)): ?>
<?php $component = $__componentOriginal3393560a65f36031a8fc2de39b5ab719; ?>
<?php unset($__componentOriginal3393560a65f36031a8fc2de39b5ab719); ?>
<?php endif; ?>
                        </td>
                        <td>
                            <strong>
                                <?php if (isset($component)) { $__componentOriginald49e61fa434bee7de04555c8528c400a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald49e61fa434bee7de04555c8528c400a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-time','data' => ['time' => $subRoute['depart_time']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-time'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['time' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['depart_time'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald49e61fa434bee7de04555c8528c400a)): ?>
<?php $attributes = $__attributesOriginald49e61fa434bee7de04555c8528c400a; ?>
<?php unset($__attributesOriginald49e61fa434bee7de04555c8528c400a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald49e61fa434bee7de04555c8528c400a)): ?>
<?php $component = $__componentOriginald49e61fa434bee7de04555c8528c400a; ?>
<?php unset($__componentOriginald49e61fa434bee7de04555c8528c400a); ?>
<?php endif; ?></strong>
                            <br><small><?php echo e($subRoute['origin_timezone']); ?></small>
                        </td>
                        <td>
                            <?php if (isset($component)) { $__componentOriginald49e61fa434bee7de04555c8528c400a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald49e61fa434bee7de04555c8528c400a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-time','data' => ['time' => $subRoute['arrival_time']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-time'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['time' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['arrival_time'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald49e61fa434bee7de04555c8528c400a)): ?>
<?php $attributes = $__attributesOriginald49e61fa434bee7de04555c8528c400a; ?>
<?php unset($__attributesOriginald49e61fa434bee7de04555c8528c400a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald49e61fa434bee7de04555c8528c400a)): ?>
<?php $component = $__componentOriginald49e61fa434bee7de04555c8528c400a; ?>
<?php unset($__componentOriginald49e61fa434bee7de04555c8528c400a); ?>
<?php endif; ?>
                            <br><small><?php echo e($subRoute['destination_timezone']); ?></small>
                        </td>
                        <td class="">
                            <?php if($subRoute['type']=='activity'): ?>
                            <span class="badge bg-label-info">Activity route</span><br>
                            <?php endif; ?>
                            <?php echo e($subRoute['boat_type']); ?> <br />

                            <div class="col-12 d-flex align-items-center flex-wrap">

                                <?php if(!empty($subRoute['icons'])): ?>
                                <?php $__currentLoopData = $subRoute['icons']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="avatar avatar-sm me-4 position-relative">
                                    <img src="<?php echo e($icon); ?>" alt="Avatar">
                                    <small></small>

                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <?php if (isset($component)) { $__componentOriginaldb12de5da9d1678ccad864eb19c0c030 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb12de5da9d1678ccad864eb19c0c030 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-number','data' => ['number' => $subRoute['seatamt']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['seatamt'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb12de5da9d1678ccad864eb19c0c030)): ?>
<?php $attributes = $__attributesOriginaldb12de5da9d1678ccad864eb19c0c030; ?>
<?php unset($__attributesOriginaldb12de5da9d1678ccad864eb19c0c030); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb12de5da9d1678ccad864eb19c0c030)): ?>
<?php $component = $__componentOriginaldb12de5da9d1678ccad864eb19c0c030; ?>
<?php unset($__componentOriginaldb12de5da9d1678ccad864eb19c0c030); ?>
<?php endif; ?>
                        </td>
                        <td class="">
                            <small>
                                <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['price' => $subRoute['cost_price']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['price' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['cost_price'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?></small>
                            <input type="number" name="price" id="" class="form-control" value="<?php echo e($subRoute['price']); ?>">
                        </td>

                        <td class="">
                            <small>
                                <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['price' => $subRoute['cost_child_price']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['price' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['cost_child_price'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?></small>
                            <input type="number" name="child_price" id="" class="form-control" value="<?php echo e($subRoute['child_price']); ?>">
                        </td>

                        <td class="">
                            <small>
                                <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['price' => $subRoute['cost_infant_price']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['price' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subRoute['cost_infant_price'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?></small>
                            <input type="number" name="infant_price" id="" class="form-control" value="<?php echo e($subRoute['infant_price']); ?>">
                        </td>
                        <td class="text-end">
                            <input type="hidden" name="agent_sub_route_id" id="agent_sub_route_id" value="<?php echo e($subRoute['agent_sub_route_id']); ?>">
                            <div class="d-flex align-items-center">
                                <button class="btn btn-success rounded-pill waves-effect btn-icon me-3 save-bt" disabled><i class="base-icon ti tabler-device-floppy"></i></button>



                            </div>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script>
    let isFormDirty = false;

    $(document).ready(function() {


        $(document).on('change', 'tr input[type="number"]', function() {
            const $row = $(this).closest('tr'); // หาแถว (row) ที่มี input เปลี่ยน
            const $saveBtn = $row.find('.save-bt'); // หา save button ในแถวเดียวกัน

            // Enable ปุ่ม ถ้ายัง disabled
            if ($saveBtn.prop('disabled')) {
                $saveBtn.prop('disabled', false);
                isFormDirty = true;
            }
        });

        $(document).on('change', 'tr input.switch-input', function() {
            const $row = $(this).closest('tr');
            const token = $('meta[name="csrf-token"]').attr('content');

            const subRouteId = $row.find('input[name="agent_sub_route_id"]').val();
            let isactive = $row.find('input[name="isactive"]').val();
            isactive = isactive == 'Y' ? 'N' : 'Y';
            $row.find('input[name="isactive"]').val(isactive)

            console.log({
                isactive: isactive
                , agent_sub_route_id: subRouteId
            });


            $.ajax({
                url: '/api/agent-route/save'
                , method: 'POST'
                , data: {
                    _token: token
                    , isactive: isactive
                    , agent_sub_route_id: subRouteId
                }
                , success: function(res) {
                    //console.log(res);
                    showSuccess();
                }
                , error: function() {
                    alert('เกิดข้อผิดพลาด');
                }
            });


        });

        $('.save-bt').on('click', function() {
            const $row = $(this).closest('tr');
            const $saveBtn = $(this);
            // ดึงข้อมูลจากแต่ละ input/select/checkbox
            const token = $('meta[name="csrf-token"]').attr('content');

            const price = $row.find('input[name="price"]').val();
            const childPrice = $row.find('input[name="infant_price"]').val();
            const infantPrice = $row.find('input[name="infant_price"]').val();
            const subRouteId = $row.find('input[name="agent_sub_route_id"]').val();

            console.log({
                regular_price: price
                , child_price: childPrice
                , infant_price: infantPrice
                , agent_sub_route_id: subRouteId
            });

            $.ajax({
                url: '/api/agent-route/save'
                , method: 'POST'
                , data: {
                    _token: token
                    , price: price
                    , child_price: childPrice
                    , infant_price: infantPrice
                    , agent_sub_route_id: subRouteId
                }
                , success: function(res) {
                    console.log(res.message);
                    isFormDirty = false;
                    $saveBtn.prop('disabled', true);

                    showSuccess();
                }
                , error: function() {
                    alert('เกิดข้อผิดพลาด');
                }
            });
        });

    });

    // เตือนก่อนออกจากหน้า ถ้ามีการแก้ไข
    window.addEventListener('beforeunload', function(e) {
        if (isFormDirty) {
            e.preventDefault(); // บาง browser ต้องการ
            e.returnValue = ''; // สำคัญ: ต้องมีค่านี้เพื่อให้ browser แสดง prompt
            return ''; // เผื่อ browser เก่า
        }
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\Git\ferry-sirilanta-admin\resources\views/pages/route/index.blade.php ENDPATH**/ ?>
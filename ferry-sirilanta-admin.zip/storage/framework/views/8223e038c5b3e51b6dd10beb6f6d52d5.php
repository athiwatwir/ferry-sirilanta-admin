<!doctype html>

<html lang="en" class="layout-compact layout-menu-fixed" dir="ltr" data-skin="default" data-assets-path="../../assets/" data-template="horizontal-menu-template-no-customizer-starter" data-bs-theme="light">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(env('APP_NAME')); ?>:<?php echo e($title??''); ?></title>

    <meta name="description" content="" />
    <link rel="icon" type="image/png" href="<?php echo e(asset('favicon/favicon-96x96.png')); ?>" sizes="96x96" />
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('favicon/favicon.svg')); ?>" />
    <link rel="shortcut icon" href="<?php echo e(asset('favicon/favicon.ico')); ?>" />
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('favicon/apple-touch-icon.png')); ?>" />
    <meta name="apple-mobile-web-app-title" content="168789chang.com" />


    <?php echo $__env->make('layouts.section.style', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <div class="loader-overlay">
        <div class="loader"></div>
    </div>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-navbar-full layout-horizontal layout-without-menu">
        <div class="layout-container">
            <!-- Navbar -->

            <?php echo $__env->make('layouts.section.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- / Navbar -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Menu -->
                    <?php echo $__env->make('layouts.section.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <!-- / Menu -->

                    <!-- Content -->
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <?php if(isset($breadcrumbs)): ?>
                        <?php
                        $backUrl = '';
                        ?>
                        <div class="row">
                            <div class="col-12 col-lg-10">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($loop->last): ?>
                                        <li class="breadcrumb-item active"><?php echo e($index); ?></li>
                                        <?php else: ?>
                                        <li class="breadcrumb-item">
                                            <a href="<?php echo e($item); ?>"><?php echo e($index); ?></a>
                                        </li>
                                        <?php
                                        $backUrl = $item;
                                        ?>
                                        <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                </nav>
                            </div>
                            <div class="col-12 col-lg-2 text-end">
                                <?php if(sizeof($breadcrumbs)>1): ?>
                                <a href="<?php echo e($backUrl); ?>" class="btn btn-outline-secondary mb-2 waves-effect btn-hover"><i class="icon-base ti tabler-square-rounded-chevrons-left"></i> BACK</a>
                                <?php endif; ?>
                            </div>
                        </div>

                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($title)): ?>
                        <h1 class="h3 d-flex align-items-center text-primary">
                            <?php echo e($title); ?>

                        </h1>
                        <?php endif; ?>
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                    <!--/ Content -->

                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl">
                            <div class="footer-container d-flex align-items-center justify-content-between py-4 flex-md-row flex-column">
                                <div class="text-body">
                                    ©
                                    <script>
                                        document.write(new Date().getFullYear());

                                    </script>

                                </div>
                                <div class="d-none d-lg-inline-block">

                                </div>
                            </div>
                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!--/ Content wrapper -->
            </div>

            <!--/ Layout container -->
        </div>
    </div>

    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>

    <!-- Drag Target Area To SlideIn Menu On Small Screens -->
    <div class="drag-target"></div>

    <?php echo $__env->yieldContent('modal'); ?>

    <!--/ Layout wrapper -->

    <?php echo $__env->make('layouts.section.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH D:\projects\Git\ferry-sirilanta-admin\resources\views/layouts/default.blade.php ENDPATH**/ ?>
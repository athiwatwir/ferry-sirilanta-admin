<div <?php echo e($attributes->merge(['class' => 'card p-4 mb-4'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\projects\Git\ferry-sirilanta-admin\resources\views/components/card.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12 text-end mb-3">
            <?php if (isset($component)) { $__componentOriginal2ddbcc2abbd70977e6b075de7cbd13eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbcc2abbd70977e6b075de7cbd13eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button.new','data' => ['href' => route('booking.routeFillter'),'text' => 'Create New Booking']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button.new'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('booking.routeFillter')),'text' => 'Create New Booking']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbcc2abbd70977e6b075de7cbd13eb)): ?>
<?php $attributes = $__attributesOriginal2ddbcc2abbd70977e6b075de7cbd13eb; ?>
<?php unset($__attributesOriginal2ddbcc2abbd70977e6b075de7cbd13eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbcc2abbd70977e6b075de7cbd13eb)): ?>
<?php $component = $__componentOriginal2ddbcc2abbd70977e6b075de7cbd13eb; ?>
<?php unset($__componentOriginal2ddbcc2abbd70977e6b075de7cbd13eb); ?>
<?php endif; ?>
        </div>
        <div class="col-12">
            <?php if (isset($component)) { $__componentOriginal09d952712d1cb5c69a26aa0fc519f3dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal09d952712d1cb5c69a26aa0fc519f3dc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table.datatabble','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table.datatabble'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <thead>
                    <tr>
                        <th>BookingNo.</th>
                        <th>Travel Date</th>
                        <th>Booking Date</th>
                        <th>Ticket No</th>
                        <th>Route</th>
                        <th>Passenger</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal09d952712d1cb5c69a26aa0fc519f3dc)): ?>
<?php $attributes = $__attributesOriginal09d952712d1cb5c69a26aa0fc519f3dc; ?>
<?php unset($__attributesOriginal09d952712d1cb5c69a26aa0fc519f3dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal09d952712d1cb5c69a26aa0fc519f3dc)): ?>
<?php $component = $__componentOriginal09d952712d1cb5c69a26aa0fc519f3dc; ?>
<?php unset($__componentOriginal09d952712d1cb5c69a26aa0fc519f3dc); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\Git\ferry-sirilanta-admin\resources\views/pages/booking/index.blade.php ENDPATH**/ ?>
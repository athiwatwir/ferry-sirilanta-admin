@extends('layouts.default')

@section('content')
<x-card>
    <div class="row">
        <div class="col-12 text-end mb-3">
            <x-button.new :href="route('booking.routeFillter')" text="Create New Booking" />
        </div>
        <div class="col-12">
            <x-table.datatabble>
                <thead>
                    <tr>
                        <th>BookingNo.</th>
                        <th>Travel Date</th>
                        <th>Booking Date</th>
                        <th>Ticket No</th>
                        <th>Route</th>
                        <th>Passenger</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </x-table.datatabble>
        </div>
    </div>
</x-card>

@stop

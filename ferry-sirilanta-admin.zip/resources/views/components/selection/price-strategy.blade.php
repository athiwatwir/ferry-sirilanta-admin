<x-form.float.selection name="price_strategy_id" label="Price Strategy" :options="$priceStrategies" :isempty="true" :isrequire="false" />

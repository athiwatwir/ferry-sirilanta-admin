@props([
'number'=>0
])

<span>{{ number_format($number,0) }}</span>

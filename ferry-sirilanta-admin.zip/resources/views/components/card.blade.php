<div {{ $attributes->merge(['class' => 'card p-4 mb-4']) }}>
    {{ $slot }}
</div>

@props([
'price'=>0
])

<span>{{ number_format($price,2) }}฿</span>

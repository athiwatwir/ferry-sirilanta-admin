@props([
'url'=>''
])

<a href="javascript:void(0);" class="text-danger delete-button" data-action="{{ $url }}"><i class="icon-base ti tabler-trash me-1"></i></a>

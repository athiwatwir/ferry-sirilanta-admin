@props([
'url'=>''
])

<a href="{{ $url }}" class="btn btn-text-secondary rounded-pill waves-effect btn-icon"><i class="icon-base ti tabler-edit icon-22px"></i></a>

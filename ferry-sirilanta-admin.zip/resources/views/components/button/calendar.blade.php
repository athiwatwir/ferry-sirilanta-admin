 @props([
 'href'=>'#'
 ])

 <a href="{{ $href }}" class="btn btn-secondary text-white me-2 btn-icon  waves-effect waves-light rounded-pill btn-hover" data-bs-toggle="tooltip" target="_blank" title="Schedule on calendar view" data-bs-placement="left"><i class="base-icon ti tabler-calendar-clock"></i></a>

@props(['type'])

<span>{{ $types[$type] }}</span>
